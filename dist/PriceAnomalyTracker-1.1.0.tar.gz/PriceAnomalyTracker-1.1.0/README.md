# PriceAnomalyTracker

PriceAnomalyTracker is a Python library for detecting anomalies in time series data. Using unsupervised learning methods, it applies clustering techniques (such as K-Means and DBSCAN) and normality tests (such as the Shapiro Test) to identify anomalies in a wide range of data.

PriceAnomalyTracker can be applied in various domains, including finance, fraud detection, sensor monitoring, product price analysis, and more.

PriceAnomalyTracker is particularly useful when you need to detect anomalies within a single group of data. For example, it can be used to identify anomalous prices in the sale of a specific car model, where prices should be close and follow a similar trend. The library is versatile enough to be applied in various situations where you want to uncover discrepancies in data sharing common characteristics.


## Installation and Usage

From PyPI:

```
pip install PriceAnomalyTracker
```

```
# Example usage to detect anomalies in the prices of a specific product

import PriceAnomalyTracker

data = [4250.2, 6665.5, 6665.6, 6665.56, 6135.12, 6665.6, 6672.2, 7221.1, 7221.1, 7799.0, 7852.9]

results = PriceAnomalyTracker(data)

for item in results:
    value, is_anomaly = item
    if is_anomaly:
        print(f"Anomaly detected: {value}")
    else:
        print(f"Normal value: {value}")
```

From GitHub:

```
!git clone https://github.com/RobertoJuniorXYZ/PriceAnomalyTracker.git
```

```
# Example usage to detect anomalies in the prices of a specific product

import sys
sys.path.append('PriceAnomalyTracker')

from PriceAnomalyTracker import PriceAnomalyTracker

data = [4250.2, 6665.5, 6665.6, 6665.56, 6135.12, 6665.6, 6672.2, 7221.1, 7221.1, 7799.0, 7852.9]

results = PriceAnomalyTracker(data)

for item in results:
    value, is_anomaly = item
    if is_anomaly:
        print(f"Anomaly detected: {value}")
    else:
        print(f"Normal value: {value}")
```


## Parameters
#### data (Required):
A list containing the values to be analyzed.
#### threshold_shapiro (Optional):
The significance level for the Shapiro normality test (default is 0.05).
#### init_clusters (Optional):
The maximum number of clusters to be tested in the K-Means method (default is 10).
#### min_samples (Optional):
The minimum number of samples to form a cluster in DBSCAN (default is 2).
#### min_length (Optional):
The minimum data length to set min_samples as half of this value (default is 5).
#### sense (Optional):
A factor to adjust the anomaly threshold (default is 1).


## Contribution
If you encounter any issues or wish to contribute to improving PriceAnomalyTracker, feel free to create an issue in the repository or submit a pull request.


## Licença
The MIT License (MIT)

Copyright (c) 2023 Roberto Junior

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.